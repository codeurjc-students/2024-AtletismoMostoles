package com.example.TFG_WebApp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TfgWebAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(TfgWebAppApplication.class, args);
	}

}
