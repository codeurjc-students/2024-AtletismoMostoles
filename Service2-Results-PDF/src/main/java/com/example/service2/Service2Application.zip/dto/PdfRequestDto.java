package com.example.service2.dto;

public class PdfRequestDto {
    private String atletaId;

    public String getAtletaId() {
        return atletaId;
    }

    public void setAtletaId(String atletaId) {
        this.atletaId = atletaId;
    }
}
