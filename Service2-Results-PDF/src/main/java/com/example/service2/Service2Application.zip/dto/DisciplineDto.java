package com.example.service2.dto;

public class DisciplineDto {
    private Long id;
    private String name;

    public String getName() {
        return name;
    }
}
